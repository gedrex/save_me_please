import os

__version__ = '3.6.dev0'

PHOTOLOGUE_APP_DIR = os.path.dirname(os.path.abspath(__file__))
