.. We want the CHANGELOG to also appear in the docs but we don't want to break
   the DRY principle. So we simply include the CHANGELOG from the base directory.

.. include:: ../../CHANGELOG.txt
